package com.example.krupali.job.jobseeker.subcategoryrecyclerview;

/**
 * Created by Krupali on 25-03-2019.
 */

public class Beansub {

    public String title;
    public String image;



    public Beansub() {
    }

    public Beansub(String title, String image) {

        this.title = title;
        this.image = image;

    }
}
