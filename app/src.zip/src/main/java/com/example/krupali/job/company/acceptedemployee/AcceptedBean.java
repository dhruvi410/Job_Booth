package com.example.krupali.job.company.acceptedemployee;

/**
 * Created by Krupali on 07-04-2019.
 */

public class AcceptedBean {

    public String name,title,img;

    public AcceptedBean(String name, String title, String img) {
        this.name = name;
        this.title = title;
        this.img = img;
    }

    public AcceptedBean() {
    }

    public AcceptedBean(String name, String title) {
        this.name = name;
        this.title = title;
    }
}
