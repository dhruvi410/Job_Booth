package com.example.krupali.job.jobseeker.categoryrecyclerview;

import android.content.Intent;


public class BeanCat {


    public String title;
    public String image;



    public BeanCat() {
    }

    public BeanCat(String title, String image) {

        this.title = title;
        this.image = image;

    }
}
