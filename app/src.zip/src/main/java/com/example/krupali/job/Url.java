package com.example.krupali.job;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Created by Krupali on 22-03-2019.
 */

public class Url {

    //http://192.168.43.162/job_project/
    //192.168.42.202
    // lenovo laptop 192.168.43.222
    public static String URL="http:// 192.168.43.182/job_project/";
    public static String METHOD="add";

    public static boolean isEmailValid(String email) {
        String expression = "^[\\w\\.-]+@([\\w\\-]+\\.)+[A-Z]{2,4}$";
        Pattern pattern = Pattern.compile(expression, Pattern.CASE_INSENSITIVE);
        Matcher matcher = pattern.matcher(email);
        return matcher.matches();
    }
}
